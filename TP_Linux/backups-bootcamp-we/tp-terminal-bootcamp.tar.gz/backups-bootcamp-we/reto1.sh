# Primer reto de Bash-shell
# Voy a definir dos variables la cuales las voy a definir a continuacion

option="tomas"
result=6

echo "Cree una variable con un string y la otra con un numero entero"
echo "El valor de option es: $option"
echo "El valor de result es: $result"
